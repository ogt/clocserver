machine-learning
================
[![Build Status](https://secure.travis-ci.org/antonell/contractor-recommendations.png?branch=master)](http://travis-ci.org/antonell/contractor-recommendations)

A simple example of using machine learning algorithms to make recommendations of contractors based 
on their past success/failures being hired for a particular jobs. Uses liblinear.

To run locally:
```
> mvn clean install
> java -cp 'target/classes:target/dependency/*' ContractorRecommendationsTraining
```
This will create/update a few files in the `data/test/output` folder. 
Thats all.

To run on heroku:
```
> cd contractor-recommendations/
> heroku create
> git push heroku master
> heroku run "java -cp target/classes:target/dependency/* ContractorRecommendationsTraining"
```

Remember to `heroku destroy` the app at the end.

To skip tests you can run: `mvn -DskipTests=true clean install`
To set the Java max heap size: `java -Xmx60G -DskipTests=true -cp target/classes:target/dependency/* ContractorRecommendationsTraining`
