package util;


public class MakeFromDomException extends Exception {
	private static final long serialVersionUID = 1928914949911447863L;
	private static final String __CVS_VERSION = "@{#}CVS versionInfo: $Id: MakeFromDomException.java 104874 2010-09-30 21:30:17Z cc $";
		public MakeFromDomException() {}
	public MakeFromDomException(String msg) {super(msg);}
}
