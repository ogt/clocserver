import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.mutable.MutableInt;

import de.bwaldvogel.liblinear.Predict;
import de.bwaldvogel.liblinear.Train;


import util.BuildUtils;
import util.CSVParser.MetaData;
import util.CSVParser.Row;
import util.Fmt;
import util.TaskUtils;
import util.CSVParser;



/**
 * @author Yanni Antonellis antonellis@odesk.com
 */
public class ContractorRecommendationsTraining{

	private static Logger log = Logger.getLogger(ContractorRecommendationsTraining.class.toString());

	public static enum ColName {
		OPENING_TITLE, CONTRACTOR_TITLE, CONTRACTOR_BLURB
//		OPENING_TITLE, OPENING_DESC, OPENING_EST_DURATION, OPENING_SKILLS, OPENING_TYPE,
//		CONTRACTOR_NAME, CONTRACTOR_TITLE, CONTRACTOR_BLURB, CONTRACTOR_SKILLS, CONTRACTOR_RATE, CONTRACTOR_HOURS_BILLED, CONTRACTOR_COUNTRY, CONTRACTOR_LAST_ACTIVE, CONTRACTOR_NO_TESTS, CONTRACTOR_FEEDBACK, CONTRACTOR_HAS_IMAGE,
	};

	protected Map<String, String> params;
	protected String inputPath;
	protected String testingPath;
	
	protected int maxPositiveTrainingExamples;
	protected int maxNegativeTrainingExamples;
	protected int maxPositiveTestingExamples;
	protected int maxNegativeTestingExamples;
	protected String outputPath;
	protected String tmpPath;
	protected String dictionaryFile;

	protected boolean outputModel;
	protected boolean loadIdf;
	protected boolean useTestingData;

	protected List<OpeningContractorPair> positiveTrainingExamples;
	protected List<OpeningContractorPair> negativeTrainingExamples;
	
	protected List<OpeningContractorPair> positiveTestingExamples;
	protected List<OpeningContractorPair> negativeTestingExamples;
	
	public ContractorRecommendationsTraining(String xml) {
		this.positiveTrainingExamples = new ArrayList<OpeningContractorPair>();
		this.negativeTrainingExamples = new ArrayList<OpeningContractorPair>();
		this.positiveTestingExamples = new ArrayList<OpeningContractorPair>();
		this.negativeTestingExamples = new ArrayList<OpeningContractorPair>();
		
		params = TaskUtils.parseXmlParameter(xml, "ContractorRecommendationsTraining");
		Map boundParams = TaskUtils.bindBeanWithParameters(this, params);
		log.info("bound params " + boundParams.toString());
	}

	public static void main(String[] argv) {
		String xml = "<ContractorRecommendationsTraining>"
				+ "<inputPath>data/test/</inputPath>"
				+ "<tmpPath>/tmp/</tmpPath>"
				+ "<outputPath>data/test/output/</outputPath>"
				+ "<testingPath>data/test/testing/</testingPath>"
				+ "<outputModel>false</outputModel>"
				+ "<useTestingData>true</useTestingData>"
				+ "<loadIdf>false</loadIdf>"
				+ "<maxPositiveTrainingExamples>-1</maxPositiveTrainingExamples>"
				+ "<maxNegativeTrainingExamples>-1</maxNegativeTrainingExamples>"
				+ "<maxPositiveTestingExamples>-1</maxPositiveTestingExamples>"
				+ "<maxNegativeTestingExamples>-1</maxNegativeTestingExamples>"
				+ "</ContractorRecommendationsTraining>";

		ContractorRecommendationsTraining contractorRecommendationsTrainer = new ContractorRecommendationsTraining(xml);

		contractorRecommendationsTrainer.doTask();

		
		
		//System.exit(0);
	}

	protected void doTask() {
		long t0 = System.currentTimeMillis();
		log.info("Training...");

		try {
			iterateTrainingExamples(inputPath, maxPositiveTrainingExamples, maxNegativeTrainingExamples, tmpPath, outputPath);
			printTrainingExamples();
			printSvmExamples(false, false, outputPath);

			if (useTestingData) {
				iterateTestingExamples(testingPath, maxPositiveTestingExamples, maxNegativeTestingExamples, tmpPath, outputPath);
				printTestingExamples();
				printSvmExamples(false, true, testingPath);
			}
			
			log.info(TaskUtils.getMemoryStatus());
			log.info("Cleaning up memory");
			this.positiveTrainingExamples.clear();
			this.negativeTrainingExamples.clear();
			System.gc();
			log.info(TaskUtils.getMemoryStatus());
			
			String[] argumentsScaleTraining = { "-o", outputPath + "svm_training.scale", "-s", outputPath + "scale.params", outputPath + "svm_training"};
			log.info("Scaling training data...");
			log.info(TaskUtils.getMemoryStatus());
			util.libsvm.SvmScaleCustom.main(argumentsScaleTraining);
			log.info("Finished scaling training data...");

			String[] argumentsTrain = new String[8];
			String[] argumentsTest = new String[8];

			
			if (this.useTestingData) {
				//First scale the testing data
				String[] argumentsScaleTesting = { "-o", outputPath + "svm_testing.scale", "-r", outputPath + "scale.params", testingPath + "svm_testing"};
				log.info("Scaling testing data...");
				log.info(TaskUtils.getMemoryStatus());
				util.libsvm.SvmScaleCustom.main(argumentsScaleTesting);
				log.info("Finished scaling testing data...");

				
				//Then train the model
				argumentsTrain[0] = "-s";
				argumentsTrain[1] = "6";
				argumentsTrain[2] = "-c";
				argumentsTrain[3] = "128";
				argumentsTrain[4] = outputPath + "svm_training.scale";
				argumentsTrain[5] = outputPath + "model";
				
				log.info("Running liblinear scaling...");
				log.info(TaskUtils.getMemoryStatus());
				Train.main(argumentsTrain);
				log.info("Finished running liblinear scaling...");
				
				//Finally, use the model to predict the testing data
				argumentsTest[0] = outputPath + "svm_testing.scale";
				argumentsTest[1] = outputPath + "model";
				argumentsTest[2] = outputPath + "testing_result";
				Predict.main(argumentsTest);
			}
			else {
				if (this.outputModel) {
					argumentsTrain[0] = "-s";
					argumentsTrain[1] = "6";
					argumentsTrain[2] = "-c";
					argumentsTrain[3] = "128";
					argumentsTrain[4] = outputPath + "svm_training.scale";
					argumentsTrain[5] = outputPath + "model";
				}
				else { // otherwise do cross validation
					argumentsTrain[0] = "-s";
					argumentsTrain[1] = "6";
					argumentsTrain[2] = "-c";
					argumentsTrain[3] = "128";
					argumentsTrain[4] = "-v";
					argumentsTrain[5] = "5";
					argumentsTrain[6] = outputPath + "svm_training.scale";
					argumentsTrain[7] = outputPath + "model";
				}
				
				log.info("Running liblinear scaling...");
				log.info(TaskUtils.getMemoryStatus());
				Train.main(argumentsTrain);
				log.info("Finished running liblinear scaling...");

			}
			
			
			log.info("Done training in ~ " + (System.currentTimeMillis() - t0) / 60000 + " minutes.");
			

		}
		catch (Exception e) {
			log.log(Level.SEVERE, Fmt.S(e));
			throw new RuntimeException(e);
		}

	}

	public void iterateTestingExamples(String path, int maxPositiveExamples, int maxNegativeExamples, String tmpPath, String outputPath) throws IOException{
		log.info("Iterating over " + (maxPositiveExamples > 0 ? ("at most " + maxPositiveExamples) : "all") + " available positive testing examples "
									+ (maxNegativeExamples > 0 ? ("at most " + maxNegativeExamples) : "all") + " available negative testing examples.");

		
		iteratePositiveTestingExamplesFromFile(path + "positive.csv", maxPositiveExamples, tmpPath, outputPath);
		iterateNegativeTestingExamplesFromFile(path + "negative.csv", maxNegativeExamples, tmpPath, outputPath);
		
		
		log.info("Done iterating over testing examples.");
	}

	private void iteratePositiveTestingExamplesFromFile(String filePath, int maxExamples, String tmpPath, String outputPath) throws IOException {
		log.info("Reading positive testing examples from file " + filePath + " ...");

		CSVParser parser = new CSVParser();
		parser.setParseHeader(true);
		parser.setQuoted(true);
		parser.setDelimiter(',');

		PositiveCsvHandler handler = new PositiveCsvHandler();
		handler.setMaxExamples(maxExamples);
		handler.setIsTesting(true);

		parser.addHandler(handler);

		parser.parse(new File(filePath));
		log.info("Done reading positive testing examples.");
	}
	
	private void iterateNegativeTestingExamplesFromFile(String filePath, int maxExamples, String tmpPath, String outputPath) throws IOException {
		log.info("Reading negative testing examples from file " + filePath + " ...");

		CSVParser parser = new CSVParser();
		parser.setParseHeader(true);
		parser.setQuoted(true);
		parser.setDelimiter(',');

		NegativeCsvHandler handler = new NegativeCsvHandler();
		handler.setMaxExamples(maxExamples);
		handler.setIsTesting(true);

		parser.addHandler(handler);

		parser.parse(new File(filePath));
		log.info("Done reading negative testing examples.");
	}
	
	public void iterateTrainingExamples(String path, int maxPositiveExamples, int maxNegativeExamples, String tmpPath, String outputPath) throws IOException{
		log.info("Iterating over " + (maxPositiveExamples > 0 ? ("at most " + maxPositiveExamples) : "all") + " available positive training examples "
									+ (maxNegativeExamples > 0 ? ("at most " + maxNegativeExamples) : "all") + " available negative training examples.");

		
		iteratePositiveTrainingExamplesFromFile(path + "positive.csv", maxPositiveExamples, tmpPath, outputPath);
		iterateNegativeTrainingExamplesFromFile(path + "negative.csv", maxNegativeExamples, tmpPath, outputPath);
		
		
		log.info("Done iterating over training examples.");
	}

	private void iteratePositiveTrainingExamplesFromFile(String filePath, int maxExamples, String tmpPath, String outputPath) throws IOException {
		log.info("Reading positive training examples from file " + filePath + " ...");

		CSVParser parser = new CSVParser();
		parser.setParseHeader(true);
		parser.setQuoted(true);
		parser.setDelimiter(',');

		PositiveCsvHandler handler = new PositiveCsvHandler();
		handler.setMaxExamples(maxExamples);
		handler.setIsTesting(false);

		parser.addHandler(handler);

		parser.parse(new File(filePath));
		log.info("Done reading positive training examples.");
	}
	
	private void iterateNegativeTrainingExamplesFromFile(String filePath, int maxExamples, String tmpPath, String outputPath) throws IOException {
		log.info("Reading negative training examples from file " + filePath + " ...");

		CSVParser parser = new CSVParser();
		parser.setParseHeader(true);
		parser.setQuoted(true);
		parser.setDelimiter(',');

		NegativeCsvHandler handler = new NegativeCsvHandler();
		handler.setMaxExamples(maxExamples);
		handler.setIsTesting(false);

		parser.addHandler(handler);

		parser.parse(new File(filePath));
		log.info("Done reading negative training examples.");
	}
	
	

	public void printTestingExamples() {
		this.printPositiveExamples(this.positiveTestingExamples, this.testingPath);
		this.printNegativeExamples(this.positiveTestingExamples, this.testingPath);
	}
	
	public void printTrainingExamples() {
		this.printPositiveExamples(this.positiveTrainingExamples, this.outputPath);
		this.printNegativeExamples(this.negativeTrainingExamples, this.outputPath);
	}

	public void printPositiveExamples(List<OpeningContractorPair> positiveExamples, String outPath) {
		BufferedWriter out = null;
		
		log.info("ready to print " + positiveExamples.size() + "positive examples");
		try {
			FileWriter fstream = new FileWriter(outPath + "positive.dat");
			out = new BufferedWriter(fstream);

			for (int k = 0; k < positiveExamples.size(); k++) {
				out.write(positiveExamples.get(k).openingTitle + " " + positiveExamples.get(k).contractorTitle + "    ");
				
				for (Entry<String, ContractorRecommendationsFeature> entry : positiveExamples.get(k).features.entrySet()) {
					out.write(entry.getKey() + " " + entry.getValue().value + " ");
				}

				out.write("\n");
			}
		}
		catch (IOException e) {
			log.log(Level.SEVERE, "Exception when printing positive examples: " + Fmt.S(e));
			throw new RuntimeException(e);
		}
		finally {
			IOUtils.closeQuietly(out);
		}
	}
	

	public void printNegativeExamples(List<OpeningContractorPair> negativeExamples, String outPath) {
		BufferedWriter out = null;
		
		log.info("ready to print " + negativeExamples.size() + "negative examples");
		try {
			FileWriter fstream = new FileWriter(outPath + "negative.dat");
			out = new BufferedWriter(fstream);

			for (int k = 0; k < negativeExamples.size(); k++) {
				out.write(negativeExamples.get(k).openingTitle + " " + negativeExamples.get(k).contractorTitle + "    ");


				for (Entry<String, ContractorRecommendationsFeature> entry : negativeExamples.get(k).features.entrySet()) {
					out.write(entry.getKey() + " " + entry.getValue().value + " ");
				}
				out.write("\n");
			}
		}
		catch (IOException e) {
			log.log(Level.SEVERE, "Exception when printing negative examples: " + Fmt.S(e));
			throw new RuntimeException(e);
		}
		finally {
			IOUtils.closeQuietly(out);
		}
		
	}

	
	
	/**
	 * Convert training data to liblinear's sparse representation
	 */

	public void printSvmExamples(boolean sampleImbalanced, boolean isTesting, String outPath) {
		List<OpeningContractorPair> trainingExamples;
		if (isTesting) {
			trainingExamples= new ArrayList<OpeningContractorPair>(positiveTestingExamples);
			if (sampleImbalanced) {
				trainingExamples.addAll(reservoirSample(negativeTestingExamples, positiveTestingExamples.size()));
			}
			else {
				trainingExamples.addAll(negativeTestingExamples);
			}
			// at this point I no longer need the positive and negative testing examples.
			positiveTestingExamples.clear();
			negativeTestingExamples.clear();
		}
		else {
			trainingExamples= new ArrayList<OpeningContractorPair>(positiveTrainingExamples);
			if (sampleImbalanced) {
				trainingExamples.addAll(reservoirSample(negativeTrainingExamples, positiveTrainingExamples.size()));
			}
			else {
				trainingExamples.addAll(negativeTrainingExamples);
			}
			
			// at this point I no longer need the positive and negative training examples.
			positiveTrainingExamples.clear();
			negativeTrainingExamples.clear();
		}

		

		// this is: String -> <featureValue, position>
		Map<String, Map<String, Integer>> features = new HashMap<String, Map<String, Integer>>();

		// this is: String -> currentPosition
		Map<String, MutableInt> count = new HashMap<String, MutableInt>();

		// this is: String -> currentPosition
		Map<String, Integer> featureIds = new HashMap<String, Integer>();
		Map<Integer, String> featureIdsInverse = new TreeMap<Integer, String>();

		// loop through all training examples to buffer values of categorical features
		for (int k = 0; k < trainingExamples.size(); k++) {
			for (Entry<String, ContractorRecommendationsFeature> entry : trainingExamples.get(k).features.entrySet()) {
				
				if (!entry.getValue().isCategorical || entry.getValue().value.equals("")) {
					continue;
				}

				String featureNameTemp = entry.getKey();

				if (k == 0 || !features.containsKey(featureNameTemp)) {
					//log.info("Initializing hash for feature " + featureNameTemp + "a");
					features.put(featureNameTemp, new HashMap<String, Integer>());
				}

				//log.info("a" + featureNameTemp + "a" + entry.getValue().value +" " +features.get(featureNameTemp) +"a");
				if (features.get(featureNameTemp).containsKey(entry.getValue().value)) {
					continue;
				}

				MutableInt featureValuePos = BuildUtils.getOrDefault(count, featureNameTemp, MutableInt.class);

				features.get(featureNameTemp).put(entry.getValue().value, featureValuePos.intValue());
				featureValuePos.increment();
			}
		}

		int prev = 0;
		int id = 1;
		for (Entry<String, MutableInt> entry : count.entrySet()) {
			featureIds.put(entry.getKey(), id);
			featureIdsInverse.put(id, entry.getKey());
			prev = entry.getValue().intValue();
			//log.info("COUNTS          " + entry.getKey() + "=" + entry.getValue());
			//log.info("IDS          " + entry.getKey() + "=" + id);
			id += prev;
			
		}
		
		BufferedWriter out = null;
		try {
			FileWriter fstream;
			if (isTesting)
				fstream = new FileWriter(outPath + "svm_testing");
			else
				fstream = new FileWriter(outPath + "svm_training");
			out = new BufferedWriter(fstream);
			
			
			for (int k = 0; k < trainingExamples.size(); k++) {

				if (trainingExamples.get(k).isPositive)
					out.write("1 ");
				else
					out.write("-1 ");

				
				/*
				for (Entry<String, ContractorRecommendationsFeature> entry : trainingExamples.get(k).features.entrySet()) {
					if (entry.getValue().isCategorical && !entry.getValue().value.equals("")) {
						int tmpCount = featureIds.get(entry.getKey()).intValue();
						out.write(tmpCount + ":1 ");
					}
					else {
						if (!entry.getValue().value.equals("")) {
							int tmpCount = featureIds.get(entry.getKey()).intValue();
							out.write(tmpCount + ":" + entry.getValue().value + " ");
							
						}
					}
				}*/
				
				
				
				for (Entry<Integer, String> e : featureIdsInverse.entrySet()) {
					String featureName = e.getValue();
					Integer featureId = e.getKey();
					
					ContractorRecommendationsFeature feature = trainingExamples.get(k).features.get(featureName);
					if (feature != null) {
						if (feature.isCategorical && !feature.value.equals("")) {
							out.write(featureId + ":1 ");
						}
						else {
							if (!feature.value.equals("")) {
								out.write(featureId + ":" + feature.value + " ");
								
							}
						}	
					}
					
				}
				
				out.write("\n");
			}

		}
		catch (IOException e) {
			log.log(Level.SEVERE, "Exception when svm formatting examples: " + Fmt.S(e));
			throw new RuntimeException(e);
		}
		finally {
			IOUtils.closeQuietly(out);
		}

		//now serialize the features to be used when generating the testing data
		ObjectOutputStream out2 = null;
		try {
			FileOutputStream fstream = new FileOutputStream(outPath + "features");
			out2 = new ObjectOutputStream(fstream);

			out2.writeObject(features);

		}
		catch (IOException e) {
			log.log(Level.SEVERE, "Exception when svm formatting examples: " + Fmt.S(e));
			throw new RuntimeException(e);
		}
		finally {
			IOUtils.closeQuietly(out);
		}
		
		
	}
	
	
	/*
	 * Reservoir sampling
	 */
	public static <T> List<T> reservoirSample(Iterable<T> items, int m) {
		Random rnd = new Random(System.currentTimeMillis());
		ArrayList<T> res = new ArrayList<T>(m);
		int count = 0;
		for (T item : items) {
			count++;
			if (count <= m) {
				res.add(item);
			}
			else {
				int r = rnd.nextInt(count);
				
				if (r < m)
					res.set(r, item);

			}
		}
		return res;

	}
	
	
	public void processPositiveExample(OpeningContractorPair pair, boolean isTesting) {
		//log.info("processing a positive example");
		if (isTesting)
			this.positiveTestingExamples.add(pair);
		else
			this.positiveTrainingExamples.add(pair);
		
	}
	
	public void processNegativeExample(OpeningContractorPair pair, boolean isTesting) {
		//log.info("processing a positive example");
		if (isTesting)
			this.negativeTestingExamples.add(pair);
		else
			this.negativeTrainingExamples.add(pair);
		
	}
	

	
	private class NegativeCsvHandler implements CSVParser.Handler {
		private Map<String, Integer> columnIdx = new HashMap<String, Integer>();
		private int maxExamples = 0;
		private boolean isTesting = false;
		private int ctr = 0;

		public void parseColumnNames(MetaData md) {
			for (int idx = 0; idx < md.getColumnNames().length; ++idx) {
				columnIdx.put(canonicalColName(md.getColumnNames()[idx]), idx);
			}
		}

		private String canonicalColName(String colName) {
			return colName.trim().toLowerCase();
		}

		private String canonicalColName(ColName colName) {
			return canonicalColName(colName.toString());
		}

		private String getField(ColName colName, Row row) {
			String canonicalColName = canonicalColName(colName);
			return columnIdx.containsKey(canonicalColName) ? row
					.getValue(columnIdx.get(canonicalColName)) : "";
		}		

		public void endDocument() {
		}

		public void row(Row row) {
			if (maxExamples > 0 && ctr > maxExamples) {
				return;
			}
			++ctr;
			
			OpeningContractorPair pair = new OpeningContractorPair(
						getField(ColName.OPENING_TITLE, row),
						getField(ColName.CONTRACTOR_TITLE, row),
						getField(ColName.CONTRACTOR_BLURB, row),
						false
						);

			processNegativeExample(pair, isTesting);
		}

		public void setIsTesting(boolean isTesting) {
			this.isTesting = isTesting;
		}

		public void setMaxExamples(int maxExamples) {
			this.maxExamples = maxExamples;
		}

		public void startDocument(MetaData metaData) {
			parseColumnNames(metaData);
			
		}


	}

	
	
	private class PositiveCsvHandler implements CSVParser.Handler {
		private Map<String, Integer> columnIdx = new HashMap<String, Integer>();
		private int maxExamples = 0;
		private boolean isTesting = false;
		private int ctr = 0;

		public void parseColumnNames(MetaData md) {
			for (int idx = 0; idx < md.getColumnNames().length; ++idx) {
				columnIdx.put(canonicalColName(md.getColumnNames()[idx]), idx);
			}
		}

		private String canonicalColName(String colName) {
			return colName.trim().toLowerCase();
		}

		private String canonicalColName(ColName colName) {
			return canonicalColName(colName.toString());
		}

		private String getField(ColName colName, Row row) {
			String canonicalColName = canonicalColName(colName);
			return columnIdx.containsKey(canonicalColName) ? row
					.getValue(columnIdx.get(canonicalColName)) : "";
		}		

		
		public void endDocument() {
		}

		public void row(Row row) {
			if (maxExamples > 0 && ctr > maxExamples) {
				return;
			}
			++ctr;
			
			OpeningContractorPair pair = new OpeningContractorPair(
						getField(ColName.OPENING_TITLE, row),
						getField(ColName.CONTRACTOR_TITLE, row),
						getField(ColName.CONTRACTOR_BLURB, row),
						true
						);

			processPositiveExample(pair, isTesting);
		}

		public void setMaxExamples(int maxExamples) {
			this.maxExamples = maxExamples;
		}
		
		public void setIsTesting(boolean isTesting) {
			this.isTesting = isTesting;
		}

		public void startDocument(MetaData metaData) {
			parseColumnNames(metaData);
			
		}


	}



	public void setOutputModel(boolean outputModel) {
		this.outputModel = outputModel;
	}

	public void setLoadIdf(boolean loadIdf) {
		this.loadIdf = loadIdf;
	}



	public void setInputPath(String inputPath) {
		this.inputPath = inputPath;
	}

	public void setDictionaryFile(String dictionaryFile) {
		this.dictionaryFile = dictionaryFile;
	}
	
	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

	public void setTmpPath(String tmpPath) {
		this.tmpPath = tmpPath;
	}
	
	public String getTestingPath() {
		return testingPath;
	}

	public void setTestingPath(String testingPath) {
		this.testingPath = testingPath;
	}

	public int getMaxPositiveTrainingExamples() {
		return maxPositiveTrainingExamples;
	}

	public void setMaxPositiveTrainingExamples(int maxPositiveTrainingExamples) {
		this.maxPositiveTrainingExamples = maxPositiveTrainingExamples;
	}

	public int getMaxNegativeTrainingExamples() {
		return maxNegativeTrainingExamples;
	}

	public void setMaxNegativeTrainingExamples(int maxNegativeTrainingExamples) {
		this.maxNegativeTrainingExamples = maxNegativeTrainingExamples;
	}

	public int getMaxPositiveTestingExamples() {
		return maxPositiveTestingExamples;
	}

	public void setMaxPositiveTestingExamples(int maxPositiveTestingExamples) {
		this.maxPositiveTestingExamples = maxPositiveTestingExamples;
	}

	public int getMaxNegativeTestingExamples() {
		return maxNegativeTestingExamples;
	}

	public void setMaxNegativeTestingExamples(int maxNegativeTestingExamples) {
		this.maxNegativeTestingExamples = maxNegativeTestingExamples;
	}

	public String getInputPath() {
		return inputPath;
	}

	public String getOutputPath() {
		return outputPath;
	}

	public String getTmpPath() {
		return tmpPath;
	}

	public String getDictionaryFile() {
		return dictionaryFile;
	}

	public boolean isOutputModel() {
		return outputModel;
	}

	public boolean isUseTestingData() {
		return useTestingData;
	}

	public void setUseTestingData(boolean useTestingData) {
		this.useTestingData = useTestingData;
	}



}
